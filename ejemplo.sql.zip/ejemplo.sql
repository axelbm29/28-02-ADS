-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 28-02-2024 a las 15:07:57
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `ejemplo`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `privilegio`
-- 

CREATE TABLE `privilegio` (
  `idPrivilegio` int(11) NOT NULL auto_increment,
  `etiquetaPrivilegio` varchar(50) NOT NULL,
  `rutaPrivilegio` varchar(200) NOT NULL,
  `iconoPrivilegio` varchar(50) NOT NULL,
  `nombrePrivilegio` varchar(30) NOT NULL,
  PRIMARY KEY  (`idPrivilegio`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `privilegio`
-- 

INSERT INTO `privilegio` VALUES (1, 'emitir boleta', '../moduloVentas/indexEmitirBoleta.php', 'boleta.png', 'btnBoleta');
INSERT INTO `privilegio` VALUES (2, 'emitir proforma', '../moduloVentas/indexEmitirProforma.php', 'proforma.png', 'btnProforma');
INSERT INTO `privilegio` VALUES (3, 'registrar despacho', '../moduloVentas/indexRegistrarDespacho.php', 'despacho.png', 'btnDespacho');
INSERT INTO `privilegio` VALUES (4, 'cambiar password', '../moduloSeguridad/indexCambiarPassword.php', 'password.png', 'btnCambioPassword');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuario`
-- 

CREATE TABLE `usuario` (
  `login` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `preguntaSecreta` varchar(100) NOT NULL,
  `respuestaSecreta` varchar(50) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY  (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `usuario`
-- 

INSERT INTO `usuario` VALUES ('gato', '12345', 'como se llama tu mascota', 'perro', 1);
INSERT INTO `usuario` VALUES ('perro', '9876', 'comno se llama tu mascota', 'gato', 1);
INSERT INTO `usuario` VALUES ('rata', '12345', 'como se llama tu mascota', 'perro', 1);
INSERT INTO `usuario` VALUES ('rana', '123456', 'como se llama tu mascota', 'perro', 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarioprivilegio`
-- 

CREATE TABLE `usuarioprivilegio` (
  `login` varchar(30) NOT NULL,
  `idPrivilegio` int(11) NOT NULL,
  KEY `FK_usuarioPrivi10` (`login`),
  KEY `FK_usuarioPrivi11` (`idPrivilegio`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `usuarioprivilegio`
-- 

INSERT INTO `usuarioprivilegio` VALUES ('gato', 1);
INSERT INTO `usuarioprivilegio` VALUES ('gato', 2);
INSERT INTO `usuarioprivilegio` VALUES ('gato', 3);
INSERT INTO `usuarioprivilegio` VALUES ('gato', 4);
INSERT INTO `usuarioprivilegio` VALUES ('perro', 2);
INSERT INTO `usuarioprivilegio` VALUES ('perro', 4);
INSERT INTO `usuarioprivilegio` VALUES ('rata', 3);
